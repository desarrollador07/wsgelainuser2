<?php

use App\Http\Controllers\testController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;



 Route::get('migration', function () {
    Artisan::call('migrate');
 });


Auth::routes();
Route::get('all', 'testController@index');
Route::post('create', 'testController@store');
Route::put('update/{id}', 'testController@update');
Route::delete('delete/{id}', 'testController@destroy');

Route::get('allp', 'pruebaController@index');
Route::post('createp', 'pruebaController@store');
Route::put('updatep/{id}', 'pruebaController@update');
Route::delete('deletep/{id}', 'pruebaController@destroy');

Route::get('allEmpresa', 'empresaController@index');
Route::post('createEmpresa', 'empresaController@store');
Route::put('updateEmpresa/{id}', 'empresaController@update');
Route::delete('deleteEmpresa/{id}', 'empresaController@destroy');

Route::get('allEmpleados', 'empleadosController@index');
Route::post('createEmpleados', 'empleadosController@store');
Route::put('updateEmpleados/{id}', 'empleadosController@update');
Route::delete('deleteEmpleados/{id}', 'empleadosController@destroy');

Route::get('allArea', 'areaController@index');
Route::post('createArea', 'areaController@store');
Route::put('updateArea/{id}', 'areaController@update');
Route::delete('deleteArea/{id}', 'areaController@destroy');